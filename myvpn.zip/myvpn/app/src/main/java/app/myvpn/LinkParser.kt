package app.myvpn

import android.net.Uri
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject

/**
 * Превращает ссылку сервера (vless://, vmess://, trojan://, ss://, hysteria2://)
 * в outbound для sing-box. Тег outbound всегда "proxy".
 */
object LinkParser {

    fun b64(s: String): String {
        var x = s.trim().replace('-', '+').replace('_', '/')
        while (x.length % 4 != 0) x += "="
        return String(Base64.decode(x, Base64.DEFAULT), Charsets.UTF_8)
    }

    private fun String?.nz(): String? = if (this.isNullOrEmpty()) null else this

    private class P(
        val user: String,
        val host: String,
        val port: Int,
        val q: Map<String, String>,
    )

    private fun parse(link: String): P {
        var rest = link.substringAfter("://")
        rest = rest.substringBefore('#')
        val query = rest.substringAfter('?', "")
        rest = rest.substringBefore('?')
        val user = Uri.decode(rest.substringBeforeLast('@', ""))
        val hp = rest.substringAfterLast('@').substringBefore('/')
        val host: String
        val port: Int
        if (hp.startsWith("[")) {
            host = hp.substringAfter('[').substringBefore(']')
            port = hp.substringAfter("]:").substringBefore(',').toInt()
        } else {
            host = hp.substringBeforeLast(':')
            port = hp.substringAfterLast(':').substringBefore(',').toInt()
        }
        val q = HashMap<String, String>()
        for (kv in query.split('&')) {
            if (kv.contains('=')) q[kv.substringBefore('=')] = Uri.decode(kv.substringAfter('='))
        }
        return P(user, host, port, q)
    }

    private fun tls(q: Map<String, String>, host: String, forceTls: Boolean): JSONObject? {
        val sec = q["security"].nz() ?: if (forceTls) "tls" else "none"
        if (sec != "tls" && sec != "reality") return null
        val t = JSONObject()
            .put("enabled", true)
            .put("server_name", q["sni"].nz() ?: q["host"].nz() ?: host)
        if (q["allowInsecure"] == "1" || q["insecure"] == "1") t.put("insecure", true)
        q["alpn"].nz()?.let { t.put("alpn", JSONArray(it.split(","))) }
        t.put(
            "utls",
            JSONObject().put("enabled", true).put("fingerprint", q["fp"].nz() ?: "chrome")
        )
        if (sec == "reality") {
            t.put(
                "reality",
                JSONObject()
                    .put("enabled", true)
                    .put("public_key", q["pbk"] ?: "")
                    .put("short_id", q["sid"] ?: "")
            )
        }
        return t
    }

    private fun transport(type: String?, path: String?, host: String?, service: String?): JSONObject? =
        when (type) {
            "ws" -> {
                val o = JSONObject().put("type", "ws").put("path", path.nz() ?: "/")
                if (host.nz() != null) o.put("headers", JSONObject().put("Host", host))
                o
            }
            "grpc" -> JSONObject().put("type", "grpc").put("service_name", service ?: "")
            "httpupgrade" -> {
                val o = JSONObject().put("type", "httpupgrade").put("path", path.nz() ?: "/")
                if (host.nz() != null) o.put("host", host)
                o
            }
            "h2", "http" -> {
                val o = JSONObject().put("type", "http").put("path", path.nz() ?: "/")
                if (host.nz() != null) o.put("host", JSONArray().put(host))
                o
            }
            else -> null
        }

    private fun vless(link: String): JSONObject {
        val p = parse(link)
        val o = JSONObject()
            .put("type", "vless").put("tag", "proxy")
            .put("server", p.host).put("server_port", p.port)
            .put("uuid", p.user)
            .put("packet_encoding", "xudp")
        p.q["flow"].nz()?.let { o.put("flow", it) }
        tls(p.q, p.host, false)?.let { o.put("tls", it) }
        transport(p.q["type"], p.q["path"], p.q["host"], p.q["serviceName"])?.let { o.put("transport", it) }
        return o
    }

    private fun vmess(link: String): JSONObject {
        val j = JSONObject(b64(link.substringAfter("://").substringBefore('#')))
        fun s(k: String): String = j.optString(k, "")
        val host = s("add")
        val o = JSONObject()
            .put("type", "vmess").put("tag", "proxy")
            .put("server", host).put("server_port", s("port").toInt())
            .put("uuid", s("id"))
            .put("security", s("scy").ifEmpty { "auto" })
            .put("alter_id", s("aid").ifEmpty { "0" }.toInt())
        val q = mapOf(
            "security" to (if (s("tls") == "tls") "tls" else "none"),
            "sni" to s("sni"),
            "host" to s("host"),
            "alpn" to s("alpn"),
            "fp" to s("fp"),
        )
        tls(q, host, false)?.let { o.put("tls", it) }
        val net = s("net")
        transport(net, s("path"), s("host"), s("path"))?.let { o.put("transport", it) }
        return o
    }

    private fun trojan(link: String): JSONObject {
        val p = parse(link)
        val o = JSONObject()
            .put("type", "trojan").put("tag", "proxy")
            .put("server", p.host).put("server_port", p.port)
            .put("password", p.user)
        tls(p.q, p.host, true)?.let { o.put("tls", it) }
        transport(p.q["type"], p.q["path"], p.q["host"], p.q["serviceName"])?.let { o.put("transport", it) }
        return o
    }

    private fun ss(link: String): JSONObject {
        var rest = link.substringAfter("://").substringBefore('#')
        rest = rest.substringBefore('?') // плагины пока не поддерживаются
        val cred: String
        val hp: String
        if (rest.contains('@')) {
            val u = rest.substringBeforeLast('@')
            hp = rest.substringAfterLast('@').substringBefore('/')
            cred = if (u.contains(':')) Uri.decode(u) else b64(u)
        } else {
            val d = b64(rest.trimEnd('/'))
            cred = d.substringBeforeLast('@')
            hp = d.substringAfterLast('@')
        }
        return JSONObject()
            .put("type", "shadowsocks").put("tag", "proxy")
            .put("server", hp.substringBeforeLast(':').trim('[', ']'))
            .put("server_port", hp.substringAfterLast(':').toInt())
            .put("method", cred.substringBefore(':'))
            .put("password", cred.substringAfter(':'))
    }

    private fun hy2(link: String): JSONObject {
        val p = parse(link)
        val o = JSONObject()
            .put("type", "hysteria2").put("tag", "proxy")
            .put("server", p.host).put("server_port", p.port)
            .put("password", p.user)
        val t = JSONObject().put("enabled", true).put("server_name", p.q["sni"].nz() ?: p.host)
        if (p.q["insecure"] == "1") t.put("insecure", true)
        o.put("tls", t)
        if (p.q["obfs"] == "salamander") {
            o.put(
                "obfs",
                JSONObject().put("type", "salamander").put("password", p.q["obfs-password"] ?: "")
            )
        }
        return o
    }

    fun outbound(link: String): JSONObject? = try {
        when {
            link.startsWith("vless://") -> vless(link)
            link.startsWith("vmess://") -> vmess(link)
            link.startsWith("trojan://") -> trojan(link)
            link.startsWith("ss://") -> ss(link)
            link.startsWith("hysteria2://") || link.startsWith("hy2://") -> hy2(link)
            else -> null
        }
    } catch (e: Exception) {
        null
    }

    /** Возвращает сервер, если ссылку удалось разобрать. */
    fun parseServer(line: String): Server? {
        val l = line.trim()
        val ob = outbound(l) ?: return null
        val name = if (l.startsWith("vmess://")) {
            try {
                JSONObject(b64(l.substringAfter("://").substringBefore('#'))).optString("ps", "")
            } catch (e: Exception) {
                ""
            }
        } else {
            Uri.decode(l.substringAfter('#', ""))
        }.ifEmpty { ob.optString("server") + ":" + ob.optInt("server_port") }
        return Server(name, l)
    }
}
