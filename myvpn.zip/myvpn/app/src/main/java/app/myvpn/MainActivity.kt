package app.myvpn

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var urlEdit: EditText
    private lateinit var infoView: TextView
    private lateinit var statusView: TextView
    private lateinit var listView: ListView
    private lateinit var connectBtn: Button

    private var servers: List<Server> = emptyList()
    private var selected = 0

    private val vpnPermission =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            if (r.resultCode == Activity.RESULT_OK) {
                startVpn()
            } else {
                Toast.makeText(this, "Нужно разрешение на VPN", Toast.LENGTH_SHORT).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        urlEdit = findViewById(R.id.urlEdit)
        infoView = findViewById(R.id.infoView)
        statusView = findViewById(R.id.statusView)
        listView = findViewById(R.id.listView)
        connectBtn = findViewById(R.id.connectBtn)

        urlEdit.setText(Store.url(this))
        servers = Store.servers(this)
        selected = Store.selected(this).coerceIn(0, maxOf(0, servers.lastIndex))
        fillList()
        if (servers.isNotEmpty()) infoView.text = "Серверов: ${servers.size}"

        listView.setOnItemClickListener { _, _, pos, _ ->
            selected = pos
            Store.setSelected(this, pos)
        }
        findViewById<Button>(R.id.updateBtn).setOnClickListener { updateSubscription() }
        connectBtn.setOnClickListener { toggle() }

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        VpnSvc.onChange = { runOnUiThread { render() } }
        render()
    }

    override fun onPause() {
        VpnSvc.onChange = null
        super.onPause()
    }

    private fun render() {
        statusView.text = VpnSvc.status
        connectBtn.text = if (VpnSvc.running) "Отключить" else "Подключить"
    }

    private fun fillList() {
        listView.choiceMode = ListView.CHOICE_MODE_SINGLE
        listView.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_single_choice,
            servers.map { it.name }
        )
        if (servers.isNotEmpty()) listView.setItemChecked(selected, true)
    }

    private fun updateSubscription() {
        val url = urlEdit.text.toString().trim()
        if (url.isEmpty()) {
            infoView.text = "Вставь ссылку подписки"
            return
        }
        Store.setUrl(this, url)
        infoView.text = "Загружаю подписку…"
        thread {
            try {
                val list = Subscription.fetch(url)
                Store.setServers(this, list)
                Store.setSelected(this, 0)
                runOnUiThread {
                    servers = list
                    selected = 0
                    fillList()
                    infoView.text = "Серверов: ${list.size}"
                }
            } catch (e: Exception) {
                runOnUiThread { infoView.text = "Ошибка: ${e.message}" }
            }
        }
    }

    private fun toggle() {
        if (VpnSvc.running) {
            startService(Intent(this, VpnSvc::class.java).setAction(VpnSvc.ACTION_STOP))
            return
        }
        val prepare = VpnService.prepare(this)
        if (prepare != null) vpnPermission.launch(prepare) else startVpn()
    }

    private fun startVpn() {
        if (servers.isEmpty()) {
            Toast.makeText(this, "Сначала загрузи подписку", Toast.LENGTH_SHORT).show()
            return
        }
        val server = servers[selected.coerceIn(0, servers.lastIndex)]
        val i = Intent(this, VpnSvc::class.java)
            .setAction(VpnSvc.ACTION_START)
            .putExtra(VpnSvc.EXTRA_LINK, server.link)
        ContextCompat.startForegroundService(this, i)
    }
}
