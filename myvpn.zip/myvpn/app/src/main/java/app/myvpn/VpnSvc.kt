package app.myvpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.ConnectivityManager
import android.net.LinkProperties
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat
import io.nekohasekai.libbox.BoxService
import io.nekohasekai.libbox.InterfaceUpdateListener
import io.nekohasekai.libbox.Libbox
import io.nekohasekai.libbox.NetworkInterface as LNetworkInterface
import io.nekohasekai.libbox.NetworkInterfaceIterator
import io.nekohasekai.libbox.PlatformInterface
import io.nekohasekai.libbox.StringIterator
import io.nekohasekai.libbox.TunOptions
import io.nekohasekai.libbox.WIFIState
import java.net.NetworkInterface as JNetworkInterface
import kotlin.concurrent.thread

private class StrIter(items: List<String>) : StringIterator {
    private val iter = items.iterator()
    override fun hasNext(): Boolean = iter.hasNext()
    override fun next(): String = iter.next()
}

/**
 * VpnService + реализация PlatformInterface для libbox (sing-box v1.8.x).
 * Если версия sing-box в workflow изменится, список методов PlatformInterface может поменяться.
 */
class VpnSvc : VpnService(), PlatformInterface {

    companion object {
        const val ACTION_START = "app.myvpn.START"
        const val ACTION_STOP = "app.myvpn.STOP"
        const val EXTRA_LINK = "link"

        @Volatile
        var running = false

        @Volatile
        var status = "Отключено"

        @Volatile
        var onChange: (() -> Unit)? = null

        @Volatile
        private var inited = false

        fun update(r: Boolean, s: String) {
            running = r
            status = s
            onChange?.invoke()
        }
    }

    private var box: BoxService? = null
    private var tun: ParcelFileDescriptor? = null
    private var netCb: ConnectivityManager.NetworkCallback? = null
    private val cm by lazy { getSystemService(ConnectivityManager::class.java) }

    // ---------- жизненный цикл ----------

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopVpn()
            return START_NOT_STICKY
        }
        val link = intent?.getStringExtra(EXTRA_LINK)
            ?: Store.servers(this).let { it.getOrNull(Store.selected(this).coerceIn(0, maxOf(0, it.lastIndex)))?.link }
        startForeground(1, notification("Подключение…"))
        thread { startVpn(link) }
        return START_NOT_STICKY
    }

    private fun startVpn(link: String?) {
        stopBox()
        try {
            update(false, "Подключение…")
            val l = link ?: throw IllegalStateException("Сервер не выбран")
            val ob = LinkParser.outbound(l) ?: throw IllegalStateException("Не удалось разобрать ссылку сервера")
            val config = ConfigBuilder.build(ob)
            Libbox.checkConfig(config)
            if (!inited) {
                val base = filesDir.absolutePath
                Libbox.setup(base, base, cacheDir.absolutePath, false)
                inited = true
            }
            val svc = Libbox.newService(config, this)
            svc.start()
            box = svc
            update(true, "Подключено")
        } catch (e: Throwable) {
            Log.e("MyVpn", "start failed", e)
            stopBox()
            update(false, "Ошибка: ${e.message}")
            stopForeground(true)
            stopSelf()
        }
    }

    private fun stopBox() {
        try {
            box?.close()
        } catch (e: Throwable) {
            Log.w("MyVpn", "close box", e)
        }
        box = null
        try {
            tun?.close()
        } catch (e: Throwable) {
        }
        tun = null
    }

    private fun stopVpn() {
        stopBox()
        update(false, "Отключено")
        stopForeground(true)
        stopSelf()
    }

    override fun onRevoke() {
        stopVpn()
    }

    override fun onDestroy() {
        stopBox()
        if (running) update(false, "Отключено")
        super.onDestroy()
    }

    private fun notification(text: String): Notification {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel("vpn", "VPN", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
        return NotificationCompat.Builder(this, "vpn")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("MyVpn")
            .setContentText(text)
            .setOngoing(true)
            .build()
    }

    // ---------- PlatformInterface ----------

    override fun usePlatformAutoDetectInterfaceControl(): Boolean = true

    override fun autoDetectInterfaceControl(fd: Int) {
        protect(fd)
    }

    override fun openTun(options: TunOptions): Int {
        val b = VpnService.Builder()
        b.setSession("MyVpn")
        b.setMtu(options.getMTU())

        var hasV6 = false
        val a4 = options.getInet4Address()
        while (a4.hasNext()) {
            val a = a4.next()
            b.addAddress(a.address(), a.prefix())
        }
        val a6 = options.getInet6Address()
        while (a6.hasNext()) {
            hasV6 = true
            val a = a6.next()
            b.addAddress(a.address(), a.prefix())
        }

        if (options.getAutoRoute()) {
            b.addDnsServer(options.getDNSServerAddress())

            val r4 = options.getInet4RouteAddress()
            if (r4.hasNext()) {
                while (r4.hasNext()) {
                    val a = r4.next()
                    b.addRoute(a.address(), a.prefix())
                }
            } else {
                b.addRoute("0.0.0.0", 0)
            }

            if (hasV6) {
                val r6 = options.getInet6RouteAddress()
                if (r6.hasNext()) {
                    while (r6.hasNext()) {
                        val a = r6.next()
                        b.addRoute(a.address(), a.prefix())
                    }
                } else {
                    b.addRoute("::", 0)
                }
            }
        }

        val pfd = b.establish() ?: throw IllegalStateException("VPN не разрешён пользователем")
        tun = pfd
        return pfd.fd
    }

    override fun writeLog(message: String) {
        Log.d("sing-box", message)
    }

    override fun useProcFS(): Boolean = false

    override fun findConnectionOwner(
        ipProtocol: Int,
        sourceAddress: String,
        sourcePort: Int,
        destinationAddress: String,
        destinationPort: Int,
    ): Int = throw UnsupportedOperationException("not supported")

    override fun packageNameByUid(uid: Int): String =
        throw UnsupportedOperationException("not supported")

    override fun uidByPackageName(packageName: String): Int =
        throw UnsupportedOperationException("not supported")

    override fun usePlatformDefaultInterfaceMonitor(): Boolean = true

    override fun startDefaultInterfaceMonitor(listener: InterfaceUpdateListener) {
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) = pushDefault(listener)
            override fun onLost(network: Network) = pushDefault(listener)
            override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) = pushDefault(listener)
            override fun onLinkPropertiesChanged(network: Network, lp: LinkProperties) = pushDefault(listener)
        }
        netCb = cb
        val req = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()
        cm.registerNetworkCallback(req, cb)
        pushDefault(listener)
    }

    override fun closeDefaultInterfaceMonitor(listener: InterfaceUpdateListener) {
        netCb?.let {
            try {
                cm.unregisterNetworkCallback(it)
            } catch (e: Exception) {
            }
        }
        netCb = null
    }

    /** Физическая сеть (не VPN) с интернетом; предпочтительно проверенная системой. */
    private fun physicalNetwork(): Network? {
        val nets = cm.allNetworks.filter { n ->
            val c = cm.getNetworkCapabilities(n)
            c != null &&
                c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                !c.hasTransport(NetworkCapabilities.TRANSPORT_VPN)
        }
        return nets.firstOrNull {
            cm.getNetworkCapabilities(it)?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true
        } ?: nets.firstOrNull()
    }

    private fun pushDefault(listener: InterfaceUpdateListener) {
        val n = physicalNetwork()
        val name = n?.let { cm.getLinkProperties(it)?.interfaceName }
        if (name == null) {
            listener.updateDefaultInterface("", -1)
            return
        }
        val idx = try {
            JNetworkInterface.getByName(name)?.index ?: -1
        } catch (e: Exception) {
            -1
        }
        listener.updateDefaultInterface(name, idx)
    }

    override fun usePlatformInterfaceGetter(): Boolean = true

    override fun getInterfaces(): NetworkInterfaceIterator {
        val list = ArrayList<LNetworkInterface>()
        for (n in cm.allNetworks) {
            val lp = cm.getLinkProperties(n) ?: continue
            val ifName = lp.interfaceName ?: continue
            val jif = try {
                JNetworkInterface.getByName(ifName)
            } catch (e: Exception) {
                null
            } ?: continue
            val ni = LNetworkInterface()
            ni.setIndex(jif.index)
            ni.setMTU(jif.mtu)
            ni.setName(jif.name)
            ni.setAddresses(
                StrIter(jif.interfaceAddresses.map { "${it.address.hostAddress}/${it.networkPrefixLength}" })
            )
            list.add(ni)
        }
        return object : NetworkInterfaceIterator {
            private val iter = list.iterator()
            override fun next(): LNetworkInterface = iter.next()
            override fun hasNext(): Boolean = iter.hasNext()
        }
    }

    override fun underNetworkExtension(): Boolean = false

    override fun readWIFIState(): WIFIState? = null

    override fun clearDNSCache() {}
}
