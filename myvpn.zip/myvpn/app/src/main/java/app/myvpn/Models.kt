package app.myvpn

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Один сервер из подписки: отображаемое имя и исходная ссылка (vless://, vmess:// и т.д.). */
data class Server(val name: String, val link: String)

/** Хранение подписки, списка серверов и выбранного сервера. */
object Store {
    private fun sp(c: Context) = c.getSharedPreferences("myvpn", Context.MODE_PRIVATE)

    fun url(c: Context): String = sp(c).getString("url", "") ?: ""

    fun setUrl(c: Context, v: String) {
        sp(c).edit().putString("url", v).apply()
    }

    fun servers(c: Context): List<Server> {
        val arr = try {
            JSONArray(sp(c).getString("servers", "[]"))
        } catch (e: Exception) {
            JSONArray()
        }
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Server(o.getString("n"), o.getString("l"))
        }
    }

    fun setServers(c: Context, list: List<Server>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("n", it.name).put("l", it.link)) }
        sp(c).edit().putString("servers", arr.toString()).apply()
    }

    fun selected(c: Context): Int = sp(c).getInt("selected", 0)

    fun setSelected(c: Context, v: Int) {
        sp(c).edit().putInt("selected", v).apply()
    }
}
