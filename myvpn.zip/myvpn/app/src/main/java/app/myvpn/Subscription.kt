package app.myvpn

import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.util.concurrent.TimeUnit

/** Загрузка подписки: GET по ссылке, в ответе base64 (или обычный текст) со ссылками по одной в строке. */
object Subscription {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    /** Блокирующий вызов: запускать не из главного потока. */
    fun fetch(url: String): List<Server> {
        val req = Request.Builder()
            .url(url)
            .header("User-Agent", "MyVpn/1.0 sing-box")
            .build()
        val body = client.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
            r.body?.string().orEmpty()
        }.trim()

        val text = if (body.contains("://")) {
            body
        } else {
            try {
                LinkParser.b64(body)
            } catch (e: Exception) {
                body
            }
        }

        val servers = text.lineSequence().mapNotNull { LinkParser.parseServer(it) }.toList()
        if (servers.isEmpty()) throw IOException("В подписке нет поддерживаемых серверов")
        return servers
    }
}
