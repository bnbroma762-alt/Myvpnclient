package app.myvpn

import org.json.JSONArray
import org.json.JSONObject

/** Собирает полный конфиг sing-box 1.8.x: TUN-вход, выбранный сервер как outbound "proxy", DNS и маршрутизация. */
object ConfigBuilder {

    fun build(proxy: JSONObject): String {
        val dns = JSONObject()
            .put(
                "servers", JSONArray()
                    .put(
                        JSONObject().put("tag", "remote")
                            .put("address", "https://1.1.1.1/dns-query")
                            .put("detour", "proxy")
                    )
                    .put(JSONObject().put("tag", "local").put("address", "local"))
            )
            .put(
                "rules", JSONArray()
                    .put(JSONObject().put("outbound", "any").put("server", "local"))
            )
            .put("strategy", "prefer_ipv4")

        val tun = JSONObject()
            .put("type", "tun")
            .put("tag", "tun-in")
            .put("inet4_address", "172.19.0.1/30")
            .put("inet6_address", "fdfe:dcba:9876::1/126")
            .put("mtu", 9000)
            .put("auto_route", true)
            .put("stack", "system")
            .put("sniff", true)

        val outbounds = JSONArray()
            .put(proxy)
            .put(JSONObject().put("type", "direct").put("tag", "direct"))
            .put(JSONObject().put("type", "block").put("tag", "block"))
            .put(JSONObject().put("type", "dns").put("tag", "dns-out"))

        val route = JSONObject()
            .put(
                "rules", JSONArray()
                    .put(JSONObject().put("protocol", "dns").put("outbound", "dns-out"))
                    .put(JSONObject().put("ip_is_private", true).put("outbound", "direct"))
            )
            .put("auto_detect_interface", true)
            .put("final", "proxy")

        return JSONObject()
            .put("log", JSONObject().put("level", "warn"))
            .put("dns", dns)
            .put("inbounds", JSONArray().put(tun))
            .put("outbounds", outbounds)
            .put("route", route)
            .toString()
    }
}
