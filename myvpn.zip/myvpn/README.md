# MyVpn — VPN-клиент для Android с подпиской

Вставляешь ссылку подписки, приложение скачивает список серверов, выбираешь сервер и нажимаешь «Подключить». Так работают Happ и INCY.

Ядро: sing-box v1.8.13 (libbox). Протоколы: VLESS (в том числе Reality), VMess, Trojan, Shadowsocks, Hysteria2.

## Как собрать APK с телефона

Android Studio не нужна. Сборка идёт в GitHub Actions.

1. Создай на GitHub пустой репозиторий `myvpn`.
2. В Termux распакуй архив и отправь код:

```bash
unzip myvpn.zip && cd myvpn
git init -b main
git add -A
git commit -m "init"
git remote add origin https://github.com/bnbroma762-alt/myvpn.git
git push -u origin main
```

   Для пуша нужен токен: пароль при запросе — это Personal Access Token с правом `repo` (или заранее `gh auth login`).

3. Открой репозиторий → вкладка **Actions** → **Build APK**. Если сборка не стартовала сама, нажми **Run workflow**.
4. Первая сборка идёт 10–15 минут: сначала собирается ядро, потом приложение.
5. Скачай `MyVpn-debug-apk` из **Artifacts** внизу страницы запуска, распакуй zip и установи `app-debug.apk`.

## Как пользоваться

1. Вставь ссылку подписки и нажми «Обновить подписку».
2. Выбери сервер в списке.
3. Нажми «Подключить» и разреши VPN.

## Структура

| Файл | Что делает |
|---|---|
| `Subscription.kt` | скачивает подписку, декодирует base64, получает список ссылок |
| `LinkParser.kt` | разбирает `vless://`, `vmess://`, `trojan://`, `ss://`, `hysteria2://` в outbound sing-box |
| `ConfigBuilder.kt` | собирает конфиг: TUN, DNS, маршрутизация |
| `VpnSvc.kt` | `VpnService` + реализация `PlatformInterface` для libbox |
| `MainActivity.kt` | экран: подписка, список серверов, кнопка |
| `.github/workflows/build.yml` | сборка `libbox.aar` и APK |

## Если сборка упала

Скопируй последние строки лога из вкладки Actions и пришли мне. Самые вероятные места:

- **Сборка libbox**: версия gomobile или NDK. Настройки в `env` и шаге `Build libbox.aar` в `build.yml`.
- **Компиляция `VpnSvc.kt`**: сигнатуры `PlatformInterface` и `Libbox.setup(...)` привязаны к sing-box v1.8.13. Если поменять `SINGBOX_VERSION`, этот файл придётся обновить под новый интерфейс.

## Что не реализовано

- Автообновление подписки по таймеру.
- Выбор приложений в обход VPN (split tunneling).
- Замер задержки серверов.
- Плагины Shadowsocks и XHTTP-транспорт.
